# Документация проекта

## 📚 Навигация по документам

### Основные документы

#### [README.md](./README.md) - Главная страница проекта
- Описание проекта
- Установка и запуск
- Базовое использование
- API интеграция
- Команды для разработки

#### [ARCHITECTURE.md](./ARCHITECTURE.md) - Архитектура приложения
- Обзор слоёв приложения
- Components, Hooks, API, Types
- Поток данных
- Error handling
- Best practices
- Расширение функциональности

#### [REFACTORING.md](./REFACTORING.md) - Детали рефакторинга
- Что было изменено
- До и после сравнение
- Новые файлы и их назначение
- Преимущества рефакторинга
- Метрики улучшений

#### [USAGE.md](./USAGE.md) - Примеры использования
- Quick Start
- Использование `useTranslation` hook
- Прямой вызов API
- Валидация данных
- 10+ практических примеров
- Best practices
- Тестирование

## 🗂️ Структура кода

```
src/
├── api/              # HTTP клиенты
│   └── translateApi.js
│
├── hooks/            # Custom React hooks
│   └── useTranslation.js
│
├── types/            # Схемы валидации (Zod)
│   └── translation.js
│
├── components/       # React компоненты
│   ├── PdfViewer.jsx
│   └── TranslationPopup.jsx
│
├── App.jsx           # Главный компонент
├── main.jsx          # Entry point
└── index.css         # Глобальные стили
```

## 🚀 Quick Links

### Для начинающих
1. Читать: [README.md](./README.md) - установка и первый запуск
2. Читать: [USAGE.md](./USAGE.md) - примеры использования

### Для разработчиков
1. Читать: [ARCHITECTURE.md](./ARCHITECTURE.md) - понять архитектуру
2. Читать: [REFACTORING.md](./REFACTORING.md) - что было сделано
3. Читать: [USAGE.md](./USAGE.md) - продвинутые примеры

### Для ревьюеров
1. Читать: [REFACTORING.md](./REFACTORING.md) - изменения и метрики
2. Читать: [ARCHITECTURE.md](./ARCHITECTURE.md) - архитектурные решения

## 📖 Основные концепции

### Слоистая архитектура

```
┌─────────────────────────────────────┐
│         Components Layer            │
│  (UI, отображение, пользовательский │
│          интерфейс)                 │
└──────────────┬──────────────────────┘
               │ Props & State
               ↓
┌─────────────────────────────────────┐
│          Hooks Layer                │
│  (State management, бизнес-логика)  │
└──────────────┬──────────────────────┘
               │ API Calls
               ↓
┌─────────────────────────────────────┐
│           API Layer                 │
│  (HTTP requests, error handling)    │
└──────────────┬──────────────────────┘
               │ Validation
               ↓
┌─────────────────────────────────────┐
│          Types Layer                │
│  (Zod schemas, type validation)     │
└─────────────────────────────────────┘
```

### Основные модули

#### 1. `useTranslation` Hook
```javascript
const { translation, isLoading, error, retry, reset } = useTranslation(
  'text to translate',
  { sourceLang: 'en', targetLang: 'ru', enabled: true }
);
```

**Что делает:**
- Управляет состоянием перевода
- Автоматически вызывает API
- Обрабатывает ошибки
- Предоставляет retry/reset

#### 2. `translateText` API
```javascript
const result = await translateText({
  text: 'Hello',
  source_lang: 'en',
  target_lang: 'ru'
});
```

**Что делает:**
- Выполняет HTTP запрос
- Валидирует запрос и ответ
- Обрабатывает ошибки
- Возвращает типизированный результат

#### 3. Zod Schemas
```javascript
const validatedData = TranslationRequestSchema.parse(data);
```

**Что делает:**
- Runtime валидация данных
- Защита от некорректных данных
- TypeScript-like типы для JavaScript

## 🔧 Часто используемые команды

```bash
# Установка зависимостей
npm install

# Запуск dev сервера
npm run dev

# Сборка для production
npm run build

# Preview production build
npm run preview
```

## 🌐 Environment Variables

```bash
# .env
VITE_API_URL=http://localhost:8000
```

## 📝 Code Style

### Naming Conventions
- **Components**: PascalCase (`TranslationPopup.jsx`)
- **Hooks**: camelCase с префиксом `use` (`useTranslation.js`)
- **API функции**: camelCase (`translateText`)
- **Константы**: UPPER_SNAKE_CASE (`API_URL`)

### File Organization
```
module/
  ├── index.js          # Public API
  ├── ModuleName.jsx    # Main component
  ├── useModule.js      # Custom hook
  └── moduleApi.js      # API client
```

## 🧪 Testing

```javascript
// Hook test example
import { renderHook } from '@testing-library/react-hooks';
import { useTranslation } from './useTranslation';

test('should translate text', async () => {
  const { result } = renderHook(() => useTranslation('Hello'));
  await waitFor(() => expect(result.current.translation).toBe('Привет'));
});
```

## 🐛 Debugging

### Логирование
```javascript
// В translateApi.js уже есть console.error
console.error('Translation error:', err);

// Для дебага можно добавить
console.log('Request:', validatedRequest);
console.log('Response:', data);
```

### Проверка валидации
```javascript
import { TranslationRequestSchema } from './types/translation';

try {
  TranslationRequestSchema.parse(data);
  console.log('✅ Valid');
} catch (error) {
  console.error('❌ Invalid:', error.errors);
}
```

## 🎯 Roadmap

### Ближайшие улучшения
- [ ] Кеширование переводов
- [ ] Debounce для API вызовов
- [ ] История переводов
- [ ] Поддержка офлайн режима
- [ ] Batch переводы

### Долгосрочные планы
- [ ] Unit тесты
- [ ] E2E тесты
- [ ] CI/CD pipeline
- [ ] Performance мониторинг
- [ ] Internationalization (i18n)

## 📞 Support

### Нашли баг?
1. Проверьте консоль браузера
2. Проверьте network tab
3. Убедитесь что API сервер запущен
4. Проверьте `.env` файл

### Нужна помощь?
1. Читайте [USAGE.md](./USAGE.md) для примеров
2. Читайте [ARCHITECTURE.md](./ARCHITECTURE.md) для понимания архитектуры
3. Проверьте JSDoc комментарии в коде

## 📄 License

Этот проект создан для образовательных целей.

## 🙏 Acknowledgments

- React Team - за отличный фреймворк
- Zod - за type-safe валидацию
- react-pdf - за PDF viewer
- Tailwind CSS - за utility-first CSS

---

**Последнее обновление:** 2025-10-19
**Версия документации:** 1.0.0

